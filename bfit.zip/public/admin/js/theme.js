
$('#owl-carousel').owlCarousel({
	autoplay: true,
	items: 1,
    loop:true,
    autoplayHoverPause : true,
    rtl: true,
    nav:false,
    dots: true,
    smartSpeed: 700,
        navText: [
      "<i class='fa fa-chevron-left'></i>",
      "<i class='fa fa-chevron-right'></i>"
      ],
   
});
